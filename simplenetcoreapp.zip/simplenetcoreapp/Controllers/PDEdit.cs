﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using simplenetcoreapp.Models;

namespace simplenetcoreapp.Controllers
{
    public class PDEdit : Controller
    {
        private readonly ILogger<PDEdit> _logger;

        private List<PersonalDetails> detailList2 = new List<PersonalDetails>();

        public PDEdit(ILogger<PDEdit> logger)
        {
            _logger = logger;

            //inheritence from PersonalDetails to DoctorProfile
            DoctorProfile Vicran = new DoctorProfile(detailList2)
            {
                FirstName = "Vikrant Shrestha",
                Address = "Kathmnandu",
                Age = 21,
                Occupation = "Doctor",
                //DoctorProfile specific property
                HospitalClinic = "Grande Hospital",
                Qualification = "MD",
                Speciality = "NeuroSurgeon"
            };
            detailList2.Add(Vicran);


            //inheritence from PersonalDetails to TeacherProfile
            TeacherProfile Sinke = new TeacherProfile(detailList2)
            {
                FirstName = "Aman Butthe",
                Address = "Darjeeling",
                Age = 20,
                Occupation = "Teacher",
                //TeacherProfile specific property
                Qualification = "B.Ed.",
                Institute = "JMC",
                AssociatedSubjects = "Mathematics"
            };
            detailList2.Add(Sinke);


            //inheritence from PersonalDetails to StudentProfile
            StudentProfile Sallu = new StudentProfile(detailList2)
            {
                FirstName = "Salina Awal",
                Address = "Bhaktapur",
                Age = 23,
                Occupation = "Student",
                //StudentProfile specific property
                Faculty = "Architecture",
                College_School = "Pulchowk",
                Rollno = 15162
            };
            detailList2.Add(Sallu);

        }



        public IActionResult PDEditor()
        {
            return View(detailList2);
        }


        public IActionResult PersonList()
        {
            return View(detailList2);
        }


// GET: PDEdit
public ActionResult Index()
        {
            return View();
        }

        

        // GET: PDEdit/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: PDEdit/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: PDEdit/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: PDEdit/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: PDEdit/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: PDEdit/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: PDEdit/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }


        public IActionResult PersonalDetails(int personDetailsID)
        {
            PersonalDetails pdetail = new PersonalDetails(detailList2);
            pdetail = detailList2.Where(x => x.PersonalDetailsID == personDetailsID).FirstOrDefault();
            return View("PersonalDetails", pdetail);
        }

        public IActionResult PersonalDetailsEdit(int personDetailsID)
        {
            PersonalDetails pdetail = new PersonalDetails(detailList2);
            pdetail = detailList2.Where(x => x.PersonalDetailsID == personDetailsID).FirstOrDefault();
            return View( pdetail);
        }



    }
}
